/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client_server_programming;

/**
 *
 * @author Simphiwe
 */
public class Client_Server_Programming {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        // TODO code application logic here
        server Server = new server(5000);
        cliii client = new cliii("127.0.0.1", 5000);  
        cliii cliu = new cliii("127.0.0.1", 5090);
        
    }
    
}
